function sub(){
  // here we are fetching the user input data by using DOM method and storing it in
  // the following varibles
  var a1 = document.getElementById("a1").value;
  var a2 = document.getElementById("a2").value;
  var a3 = document.getElementById("a3").value;
  var a4 = document.getElementById("a4").value;
  var a5 = document.getElementById("a5").value;

  // here i am again using DOM method to fetch the article data that needs to
  // changed dynamically based on the user input and assigning there value
  // to the user input value that we stored earlier in those varibales
  document.getElementById('rn').innerHTML = a1;
  document.getElementById('on').innerHTML = a2;
  document.getElementById('ed').innerHTML = a3;
  document.getElementById('wu').innerHTML = a4;
  document.getElementById('hn').innerHTML = a5;


}
